//
// Copyright (C) 2020, NinjaTrader LLC <www.ninjatrader.com>
// NinjaTrader reserves the right to modify or overwrite this NinjaScript component with each release
// Coded by NinjaTrader_Jim, NinjaTrader_ChelseaB
//
#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

// The NinjaTrader.NinjaScript.Indicators namespace holds all indicators and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Indicators.WPFManagement
{
	public class ChartTraderUIElementsFromAutomationIDsIndicatorExample : Indicator
	{
		private NinjaTrader.Gui.Tools.AccountSelector							accountSelector;
		private NinjaTrader.Gui.NinjaScript.AtmStrategy.AtmStrategySelector		atmStrategySelector;
		private NinjaTrader.Gui.Tools.InstrumentSelector						instrumentSelector;
		private NinjaTrader.Gui.Tools.QuantityUpDown							quantitySelector;
		private NinjaTrader.Gui.Tools.TifSelector								tifSelector;
		
		private NinjaTrader.Cbi.Account											currentAccount;
		private NinjaTrader.NinjaScript.AtmStrategy								currentAtmStrategy;
		private Instrument														currentInstrument;
		private	int																currentQuantity;
		private TimeInForce														currentTif;

		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description		= @"";
				Name			= "ChartTraderUIElementsFromAutomationIDsIndicatorExample";
				Calculate		= Calculate.OnBarClose;
				IsOverlay		= false;
				IsChartOnly 	= true;
			}
			else if (State == State.DataLoaded)
			{
				ClearOutputWindow();

				FindAssignUIElementsByAutomationID();
			}

			else if (State == State.Terminated)
			{
				if (ChartControl != null)
				{
					ChartControl.Dispatcher.InvokeAsync((Action)(() =>
					{
						// on script teardown remove the selection changed handlers from the charts UI controls
						if (accountSelector != null)
							accountSelector.SelectionChanged		-= AccountSelector_SelectionChanged;

						if (atmStrategySelector != null)
							atmStrategySelector.SelectionChanged	-= AtmStrategySelector_SelectionChanged;

						if (currentAccount != null)
							currentAccount.OrderUpdate				-= CurrentAccount_OrderUpdate;

						if (instrumentSelector != null)
							instrumentSelector.InstrumentChanged	-= InstrumentSelector_InstrumentChanged;

						if (quantitySelector != null)
							quantitySelector.ValueChanged			-= QuantitySelector_ValueChanged;

						if (tifSelector != null)
							tifSelector.SelectionChanged			-= TifSelector_SelectionChanged;
					}));
				}
			}
		}

		private void FindAssignUIElementsByAutomationID()
		{
			// the chart must exist to get any controls from it
			if (ChartControl != null)
			{
				// chart controls run on the UI thread. Dispatcher Invoke is used to access the thread.
				// Typically, the InvokeAsync() is used access the UI thread asynchronously when it is ready. However, if this information is needed immediately, use Invoke so that this blocks the NinjaScript thread from continuing until this operation is complete.
				// Beware that using Invoke improperly can result in deadlocks.
				// This example uses Invoke so that the UI control values are available as the historical data is processing

				ChartControl.Dispatcher.Invoke((Action)(() =>
				{
					// the window of the chart
					Window chartWindow = Window.GetWindow(ChartControl.Parent);

					// find the ChartTrader account selector by AutomationID
					accountSelector		= chartWindow.FindFirst("ChartTraderControlAccountSelector") as AccountSelector;
					if (accountSelector != null)
					{
						accountSelector.SelectionChanged		+= AccountSelector_SelectionChanged;
						currentAccount							= accountSelector.SelectedAccount;
					}

					// find the ChartTrader atmStrategy selector by AutomationID
					atmStrategySelector	= chartWindow.FindFirst("ChartTraderControlATMStrategySelector") as Gui.NinjaScript.AtmStrategy.AtmStrategySelector;
					if (atmStrategySelector != null)
					{
						atmStrategySelector.SelectionChanged	+= AtmStrategySelector_SelectionChanged;
						currentAtmStrategy						= atmStrategySelector.SelectedAtmStrategy;
					}

					instrumentSelector	= chartWindow.FindFirst("ChartTraderControlInstrumentSelector") as InstrumentSelector;
					if (instrumentSelector != null)
					{
						instrumentSelector.InstrumentChanged	+= InstrumentSelector_InstrumentChanged;
						currentInstrument						= instrumentSelector.Instrument;
					}

					// find the ChartTrader quantity selector by AutomationID
					quantitySelector	= chartWindow.FindFirst("ChartTraderControlQuantitySelector") as QuantityUpDown;
					if (quantitySelector != null)
					{
						quantitySelector.ValueChanged			+= QuantitySelector_ValueChanged;
						currentQuantity							= quantitySelector.Value;
					}

					tifSelector			= chartWindow.FindFirst("ChartTraderControlTIFSelector") as TifSelector;
					if (tifSelector != null)
					{
						tifSelector.SelectionChanged			+= TifSelector_SelectionChanged;
						currentTif								= tifSelector.SelectedTif;
					}
				}));
			}
		}

		// setting a class level value when the selection changes would prevent having to pause and invoke into the UI thread to fetch this later
		private void AccountSelector_SelectionChanged(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
		{
			if (currentAccount != null)
				currentAccount.OrderUpdate -= CurrentAccount_OrderUpdate;

			currentAccount		= accountSelector.SelectedAccount;
			if (currentAccount != null)
				Print("ChartTraderControlAccountSelector SelectedAccount: '" + currentAccount.DisplayName + "' assigned to local variable");
			else
				Print("ChartTraderControlAccountSelector null");
		}

		private void AtmStrategySelector_SelectionChanged(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
		{
			currentAtmStrategy	= atmStrategySelector.SelectedAtmStrategy;
			if (currentAtmStrategy != null)
				Print("ChartTraderControlATMStrategySelector SelectedAtmStrategy: '" + currentAtmStrategy.DisplayName + "' assigned to local variable");
			else
				Print("ChartTraderControlATMStrategySelector null");
		}

		private void CurrentAccount_OrderUpdate(object sender, OrderEventArgs e)
		{
			Print(string.Format("Account: {0} | order: {1}", currentAccount.DisplayName, e.Order));
		}

		// The instrument selector would only come into play when multiple instrument series are added to the data series window
		private void InstrumentSelector_InstrumentChanged(object sender, CancelEventArgs e)
		{
			currentInstrument	= instrumentSelector.Instrument;
			if (currentInstrument != null)
				Print("ChartTraderControlInstrumentSelector Instrument: '" + currentInstrument.FullName + "' assigned to local variable");
			else
				Print("ChartTraderControlInstrumentSelector null");
		}

		private void QuantitySelector_ValueChanged(object sender, RoutedEventArgs e)
		{
			currentQuantity		= quantitySelector.Value;
			Print("ChartTraderControlQuantitySelector Value: '" + currentQuantity + "' assigned to local variable");
		}

		private void TifSelector_SelectionChanged(object sender, RoutedEventArgs e)
		{
			currentTif			= tifSelector.SelectedTif;
			Print("ChartTraderControlTIFSelector SelectedTif: '" + currentTif + "' assigned to local variable");
		}

		protected override void OnBarUpdate()
		{
			// print out values on the last historical bar and in real-time
			if ((State == State.Historical && CurrentBar != Count - 2))
				return;
			
			// if chart trader was closed when the script was instantiated, optionally try getting these objects again before using them
			if (accountSelector == null && atmStrategySelector == null && quantitySelector == null)
				FindAssignUIElementsByAutomationID();

			// the class level values are ready after the invoke from FindUIElementsByAutomationID is finished. As these are local variables, these won't need an invoke to be used which saves processing time. They are updated from the element's change event to stay up to date.
			if (currentAccount != null)
			{
				Print(string.Format("\r\ncurrentAccount DisplayName: {1}, (Full) Name: {2}", Core.Globals.Now, currentAccount.DisplayName, currentAccount.Name));

				// The account could be used to get account information
				//Print("Account Cash Value: " + currentAccount.Get(AccountItem.CashValue, Currency.UsDollar));

				// Or could be used to add an event handler
				//currentAccount.OrderUpdate += CurrentAccount_OrderUpdate;
			}
			else
			{
				Print("currentAccount is null");
			}

			if (currentAtmStrategy != null)
			{
				Print(string.Format("currentAtmStrategy: {1}", Core.Globals.Now, currentAtmStrategy.DisplayName));

				// An atm strategy could be started from this selected atmstrategy
				//NinjaTrader.NinjaScript.AtmStrategy.StartAtmStrategy(atmStrategySelector.SelectedAtmStrategy, atmStrategySelector.Account.CreateOrder(Instrument, OrderAction.Buy, OrderType.Market, TimeInForce.Day, currentQuantity, 0, 0, string.Empty, "Buy market", null));
			}
			else
			{
				Print("currentAtmStrategy is null");
			}

			if (currentInstrument != null)
			{
				Print(string.Format("currentInstrument.Instrument: {1}", Core.Globals.Now, currentInstrument.FullName));
			}
			else
			{
				Print("currentInstrument is null");
			}
			
			// currentQuantity is an int and not a nullable type, so no check for null is needed
			Print(string.Format("currentQuantity: {1}", Core.Globals.Now, currentQuantity));

			// same for the currentTif enum
			Print(string.Format("currentTif: {1}", Core.Globals.Now, currentTif));



			// The code below demonstrates fetching these values from the UI elements directly, instead of using the values set to variables in the control change event.
			// In the instrument data driven thread OnBarUpdate(), a thread invoke would be necessary to fetch or assign these values from the UI thread elements directly (UIElement DependencyObject) which costs extra processing time.
			ChartControl.Dispatcher.InvokeAsync((Action)(() =>
			{
				if (accountSelector != null && accountSelector.SelectedAccount != null)
				{
					Print(string.Format("-\r\naccountSelector.SelectedAccount DisplayName: {1}, (Full) Name: {2}", Core.Globals.Now, accountSelector.SelectedAccount.DisplayName, accountSelector.SelectedAccount.Name));
				}
				else
					Print("accountSelector is null");

				// Note: it can be sometimes easier to just access ChartControl.OwnerChart.ChartTrader.AtmStrategy (through a dispatcher)
				if (atmStrategySelector != null && atmStrategySelector.SelectedAtmStrategy != null)
				{
					Print(string.Format("atmStrategySelector.SelectedAtmStrategy: {1}", Core.Globals.Now, atmStrategySelector.SelectedAtmStrategy.DisplayName));
				}
				else
					Print("atmStrategySelector is null");
					
				if (instrumentSelector != null)
				{
					Print(string.Format("instrumentSelector.Instrument: {1}", Core.Globals.Now, instrumentSelector.Instrument.FullName));
				}

				if (quantitySelector != null)
				{
					Print(string.Format("quantitySelector: {1}", Core.Globals.Now, quantitySelector.Value));

					// value of the quantity selector could be changed
					//quantitySelector.Value = 5;
				}
				else
				{
					Print("quantitySelector is null");
				}

				if (tifSelector != null)
				{
					Print(string.Format("tifSelector.SelectedTif: {1}", Core.Globals.Now, tifSelector.SelectedTif));

					// value of Time In Force could be changed
					//tifSelector.SelectedTif = TimeInForce.Day;
				}
				else
				{
					Print("tifSelector is null");
				}
			}));
		}
	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private WPFManagement.ChartTraderUIElementsFromAutomationIDsIndicatorExample[] cacheChartTraderUIElementsFromAutomationIDsIndicatorExample;
		public WPFManagement.ChartTraderUIElementsFromAutomationIDsIndicatorExample ChartTraderUIElementsFromAutomationIDsIndicatorExample()
		{
			return ChartTraderUIElementsFromAutomationIDsIndicatorExample(Input);
		}

		public WPFManagement.ChartTraderUIElementsFromAutomationIDsIndicatorExample ChartTraderUIElementsFromAutomationIDsIndicatorExample(ISeries<double> input)
		{
			if (cacheChartTraderUIElementsFromAutomationIDsIndicatorExample != null)
				for (int idx = 0; idx < cacheChartTraderUIElementsFromAutomationIDsIndicatorExample.Length; idx++)
					if (cacheChartTraderUIElementsFromAutomationIDsIndicatorExample[idx] != null &&  cacheChartTraderUIElementsFromAutomationIDsIndicatorExample[idx].EqualsInput(input))
						return cacheChartTraderUIElementsFromAutomationIDsIndicatorExample[idx];
			return CacheIndicator<WPFManagement.ChartTraderUIElementsFromAutomationIDsIndicatorExample>(new WPFManagement.ChartTraderUIElementsFromAutomationIDsIndicatorExample(), input, ref cacheChartTraderUIElementsFromAutomationIDsIndicatorExample);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.WPFManagement.ChartTraderUIElementsFromAutomationIDsIndicatorExample ChartTraderUIElementsFromAutomationIDsIndicatorExample()
		{
			return indicator.ChartTraderUIElementsFromAutomationIDsIndicatorExample(Input);
		}

		public Indicators.WPFManagement.ChartTraderUIElementsFromAutomationIDsIndicatorExample ChartTraderUIElementsFromAutomationIDsIndicatorExample(ISeries<double> input )
		{
			return indicator.ChartTraderUIElementsFromAutomationIDsIndicatorExample(input);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.WPFManagement.ChartTraderUIElementsFromAutomationIDsIndicatorExample ChartTraderUIElementsFromAutomationIDsIndicatorExample()
		{
			return indicator.ChartTraderUIElementsFromAutomationIDsIndicatorExample(Input);
		}

		public Indicators.WPFManagement.ChartTraderUIElementsFromAutomationIDsIndicatorExample ChartTraderUIElementsFromAutomationIDsIndicatorExample(ISeries<double> input )
		{
			return indicator.ChartTraderUIElementsFromAutomationIDsIndicatorExample(input);
		}
	}
}

#endregion
