// Made for Mack by Bjorn Poulsen, Denmark
// updated to v1.1 November 2020, line 93

#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

namespace NinjaTrader.NinjaScript.Indicators
{
	public class BPxMackPart1 : Indicator
	{
		private double			openprice,closeprice1,closeprice2,barheight,tickV;
		private Brush			Color1;
		
		
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"BPxMackPart1";
				Name										= "BPxMackPart1";
				Calculate									= Calculate.OnBarClose;
				IsOverlay									= true;
				DisplayInDataBox							= true;
				DrawOnPricePanel							= true;
				DrawHorizontalGridLines						= true;
				DrawVerticalGridLines						= true;
				PaintPriceMarkers							= false;
				IsAutoScale									= false;
				ScaleJustification							= NinjaTrader.Gui.Chart.ScaleJustification.Right;
				IsSuspendedWhileInactive					= true;
				TimeMarketOpen								= 083000;
				Zone1Color									= Brushes.White;	
				Zone1Opacity								= 1.00;
				TimeStopBackGroundColor						= 140000;
				TimeClosePrice1								= 150000;
				TimeClosePrice2								= 151500;
				ShowYdayCloseLine1								= true;
				ShowYdayCloseLine2								= true;
				
				AddPlot(new Stroke(Brushes.Gold, DashStyleHelper.Dash, 1),  PlotStyle.Hash,"TODAYOPEN");
				AddPlot(new Stroke(Brushes.SaddleBrown, DashStyleHelper.Dash, 1), PlotStyle.Hash, "YDAYCLOSE1");
				AddPlot(new Stroke(Brushes.Crimson, DashStyleHelper.Dash, 1), PlotStyle.Hash, "YDAYCLOSE2");
				AddPlot(Brushes.Orange, "BarSizeInTicks");
				AddPlot(Brushes.Crimson, "RiskIfSignal");
				
			}
			else if (State == State.Configure)
			{
			AddDataSeries(Data.BarsPeriodType.Minute, 1);
			
			}
			else if (State == State.DataLoaded)
			{
			#region color instances with opacity
				Color1 		 			= Zone1Color.Clone();
				Color1.Opacity 			= Zone1Opacity;
				
			#endregion	
			}	
		}

		protected override void OnBarUpdate()
		{
			
			if (CurrentBars[0] < 5 || CurrentBars[1] < 5)
					return;
			
			tickV=(Instrument.MasterInstrument.PointValue * Instrument.MasterInstrument.TickSize);
			barheight=(Highs[0][0]-Lows[0][0])/TickSize;
			BarSizeInTicks[0]=barheight;
			RiskIfSignal[0]=(barheight+2)*tickV;
			
			//if (ToTime(Times[1][0]) == TimeMarketOpen) changed to below to correct open price to 08:30CT
			if (ToTime(Times[1][0]) == TimeMarketOpen + 100)
			{
				openprice=Opens[1][0];
			}
			if (ToTime(Times[1][0]) == TimeClosePrice1)
			{
				closeprice1=Closes[1][0];
			}
			if (ToTime(Times[1][0]) == TimeClosePrice2)
			{
				closeprice2=Closes[1][0];
			}
				
				
					
			if (ToTime(Times[0][0]) >= TimeMarketOpen && ToTime(Times[0][0]) <= TimeStopBackGroundColor)
				{
					BackBrush = Color1;
				}
				
			
				
			if (ToTime(Times[0][0]) > TimeMarketOpen+100)
				{
				TODAYOPEN[0]=openprice;
				}
			
			if (ShowYdayCloseLine1)
				{
				YDAYCLOSE1[0]=closeprice1;
				}
				
			if (ShowYdayCloseLine2)
				{
				YDAYCLOSE2[0]=closeprice2;
				}
						
					
			
		}

		#region Properties
		
		[Range(0, int.MaxValue)]
		[NinjaScriptProperty]
		[Display(Name="Open time local: format (hhmmss)", Order=1, GroupName="1.Settings")]
		public int TimeMarketOpen
		{ get; set; }

		[XmlIgnore]
		[Display(Name="Zone1Color", Order=3, GroupName="1.Settings")]
		public Brush Zone1Color
		{ get; set; }

		[Browsable(false)]
		public string Zone1ColorSerializable
		{
			get { return Serialize.BrushToString(Zone1Color); }
			set { Zone1Color = Serialize.StringToBrush(value); }
		}
		
		[NinjaScriptProperty]
		[Range(0, double.MaxValue)]
		[Display(Name="Zone1Opacity", Description="Zone 1 Opacity ", Order=4, GroupName="1.Settings")]
		public double Zone1Opacity
		{ get; set; }
		
		
		[Range(0, int.MaxValue)]
		[NinjaScriptProperty]
		[Display(Name="Stop BackgroundColor at: format (hhmmss)", Order=5, GroupName="1.Settings")]
		public int TimeStopBackGroundColor
		{ get; set; }
		
		[NinjaScriptProperty]
		[Display(Name="Show Yday CloseLine1", Description="Show Yday Close Line1", Order=6, GroupName="1.Settings")]
		public bool ShowYdayCloseLine1
		{ get; set; }
		
		[Range(0, int.MaxValue)]
		[NinjaScriptProperty]
		[Display(Name="Closing time for line 1: format (hhmmss)", Order=7, GroupName="1.Settings")]
		public int TimeClosePrice1
		{ get; set; }
		
		[NinjaScriptProperty]
		[Display(Name="Show Yday CloseLine2", Description="Show Yday CloseLine2", Order=8, GroupName="1.Settings")]
		public bool ShowYdayCloseLine2
		{ get; set; }
		
		[Range(0, int.MaxValue)]
		[NinjaScriptProperty]
		[Display(Name="Closing time for line 2: format (hhmmss)", Order=9, GroupName="1.Settings")]
		public int TimeClosePrice2
		{ get; set; }
		
		
		
		[Browsable(false)]
		[XmlIgnore]
		public Series<double> TODAYOPEN
		{
			get { return Values[0]; }
		}

		[Browsable(false)]
		[XmlIgnore]
		public Series<double> YDAYCLOSE1
		{
			get { return Values[1]; }
		}
		
		[Browsable(false)]
		[XmlIgnore]
		public Series<double> YDAYCLOSE2
		{
			get { return Values[2]; }
		}
		
		
		[Browsable(false)]
		[XmlIgnore]
		public Series<double> BarSizeInTicks
		{
			get { return Values[3]; }
		}

		[Browsable(false)]
		[XmlIgnore]
		public Series<double> RiskIfSignal
		{
			get { return Values[4]; }
		}
		
		// Made for Mack by Bjorn Poulsen, Denmark
		
		#endregion

	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private BPxMackPart1[] cacheBPxMackPart1;
		public BPxMackPart1 BPxMackPart1(int timeMarketOpen, double zone1Opacity, int timeStopBackGroundColor, bool showYdayCloseLine1, int timeClosePrice1, bool showYdayCloseLine2, int timeClosePrice2)
		{
			return BPxMackPart1(Input, timeMarketOpen, zone1Opacity, timeStopBackGroundColor, showYdayCloseLine1, timeClosePrice1, showYdayCloseLine2, timeClosePrice2);
		}

		public BPxMackPart1 BPxMackPart1(ISeries<double> input, int timeMarketOpen, double zone1Opacity, int timeStopBackGroundColor, bool showYdayCloseLine1, int timeClosePrice1, bool showYdayCloseLine2, int timeClosePrice2)
		{
			if (cacheBPxMackPart1 != null)
				for (int idx = 0; idx < cacheBPxMackPart1.Length; idx++)
					if (cacheBPxMackPart1[idx] != null && cacheBPxMackPart1[idx].TimeMarketOpen == timeMarketOpen && cacheBPxMackPart1[idx].Zone1Opacity == zone1Opacity && cacheBPxMackPart1[idx].TimeStopBackGroundColor == timeStopBackGroundColor && cacheBPxMackPart1[idx].ShowYdayCloseLine1 == showYdayCloseLine1 && cacheBPxMackPart1[idx].TimeClosePrice1 == timeClosePrice1 && cacheBPxMackPart1[idx].ShowYdayCloseLine2 == showYdayCloseLine2 && cacheBPxMackPart1[idx].TimeClosePrice2 == timeClosePrice2 && cacheBPxMackPart1[idx].EqualsInput(input))
						return cacheBPxMackPart1[idx];
			return CacheIndicator<BPxMackPart1>(new BPxMackPart1(){ TimeMarketOpen = timeMarketOpen, Zone1Opacity = zone1Opacity, TimeStopBackGroundColor = timeStopBackGroundColor, ShowYdayCloseLine1 = showYdayCloseLine1, TimeClosePrice1 = timeClosePrice1, ShowYdayCloseLine2 = showYdayCloseLine2, TimeClosePrice2 = timeClosePrice2 }, input, ref cacheBPxMackPart1);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.BPxMackPart1 BPxMackPart1(int timeMarketOpen, double zone1Opacity, int timeStopBackGroundColor, bool showYdayCloseLine1, int timeClosePrice1, bool showYdayCloseLine2, int timeClosePrice2)
		{
			return indicator.BPxMackPart1(Input, timeMarketOpen, zone1Opacity, timeStopBackGroundColor, showYdayCloseLine1, timeClosePrice1, showYdayCloseLine2, timeClosePrice2);
		}

		public Indicators.BPxMackPart1 BPxMackPart1(ISeries<double> input , int timeMarketOpen, double zone1Opacity, int timeStopBackGroundColor, bool showYdayCloseLine1, int timeClosePrice1, bool showYdayCloseLine2, int timeClosePrice2)
		{
			return indicator.BPxMackPart1(input, timeMarketOpen, zone1Opacity, timeStopBackGroundColor, showYdayCloseLine1, timeClosePrice1, showYdayCloseLine2, timeClosePrice2);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.BPxMackPart1 BPxMackPart1(int timeMarketOpen, double zone1Opacity, int timeStopBackGroundColor, bool showYdayCloseLine1, int timeClosePrice1, bool showYdayCloseLine2, int timeClosePrice2)
		{
			return indicator.BPxMackPart1(Input, timeMarketOpen, zone1Opacity, timeStopBackGroundColor, showYdayCloseLine1, timeClosePrice1, showYdayCloseLine2, timeClosePrice2);
		}

		public Indicators.BPxMackPart1 BPxMackPart1(ISeries<double> input , int timeMarketOpen, double zone1Opacity, int timeStopBackGroundColor, bool showYdayCloseLine1, int timeClosePrice1, bool showYdayCloseLine2, int timeClosePrice2)
		{
			return indicator.BPxMackPart1(input, timeMarketOpen, zone1Opacity, timeStopBackGroundColor, showYdayCloseLine1, timeClosePrice1, showYdayCloseLine2, timeClosePrice2);
		}
	}
}

#endregion
