// Made for Mack by Bjorn Poulsen, Denmark
// Updated for ATR and various other things by Ben December 2020

#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
using Point = System.Windows.Point;
#endregion

namespace NinjaTrader.NinjaScript.Indicators
{
	public class BPxMackPart2 : Indicator
	{
		
		private	Gui.Tools.SimpleFont textFont;
		private double askprice,bidprice;
		private double atrvalue;
		private string atrstring;
		private double RangePriorBar;
		private double LongTarget;
		private double ShortTarget;
		private string RangeString; //
		private Brush _PriceLineColorDefinedbyUser = Brushes.Gray;
		
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description			= @"BPxMackPart2";
				Name				= "BPxMackPart2";
				Calculate			= Calculate.OnEachTick;
				CountDown			= true;
				DisplayInDataBox	= false;
				DrawOnPricePanel	= false;
				IsChartOnly			= true;
				IsOverlay			= true;
				ShowPercent			= false;
				PaintPriceMarkers	= false;
				textFont			= new Gui.Tools.SimpleFont("Arial", 18);
				SpreadlinesOn		= true;
				PricelineOn			= true;
				ShowTicksInCorner	= false;
				ShowATRInCorner		= false;
				ShowBarRange		= false;
				FirstExitOn			= false;
				DisplayInTicks		= true;
				
				ATRperiod			= 21;
				FirstExitThickness	= 3;
				FirstExitTicks		= 4;
								
				PriceLineColor = Brushes.Black;
				PriceLineThickness 	= 1;
				TickcounteroffsetX	= 1;
				TickcounteroffsetY  = 3;
				Spreadlineslen		= 5;
				
				AddPlot(new Stroke(Brushes.Blue, DashStyleHelper.Solid, 1), PlotStyle.Line, "EMA21");
				
			}
		}

		protected override void OnBarUpdate()
		{
			
			if (BarsInProgress != 0) 
				return;

			if (CurrentBars[0] < 1)
			return;
						
			bidprice=GetCurrentBid();
			askprice=GetCurrentAsk();
			EMA21[0]=EMA(Close,21)[0];
			
			if (DisplayInTicks)
				{
				RangePriorBar = (High[1] - Low[1]) / TickSize;
				RangeString = RangePriorBar.ToString("N0");
				}
			else
				{
				RangePriorBar = (High[1] - Low[1]);
				RangeString = RangePriorBar.ToString();
				}
				
			atrvalue=ATR(ATRperiod)[1];
			if (DisplayInTicks)
				{
				atrstring = (atrvalue / TickSize).ToString("N0");
				}
			else
				{
				atrstring = atrvalue.ToString("N2");
				}

				
			double periodValue = (BarsPeriod.BarsPeriodType == BarsPeriodType.Tick) ? BarsPeriod.Value : BarsPeriod.BaseBarsPeriodValue;
			double tickCount = ShowPercent ? CountDown ? (1 - Bars.PercentComplete) * 100 : Bars.PercentComplete * 100 : CountDown ? periodValue - Bars.TickCount : Bars.TickCount;

			string tick1 = (BarsPeriod.BarsPeriodType == BarsPeriodType.Tick 
						|| ((BarsPeriod.BarsPeriodType == BarsPeriodType.HeikenAshi || BarsPeriod.BarsPeriodType == BarsPeriodType.Volumetric) && BarsPeriod.BaseBarsPeriodType == BarsPeriodType.Tick) ? ((CountDown
										? tickCount : tickCount) + (ShowPercent ? "%" : ""))
										: NinjaTrader.Custom.Resource.TickCounterBarError);

			if (SpreadlinesOn)
			{	
				Draw.Line(this, "AskLine", false, 0, askprice, -(Spreadlineslen), askprice, Brushes.Red, DashStyleHelper.Solid, 2);	
				Draw.Line(this, "BidLine", false, 0, bidprice, -(Spreadlineslen), bidprice, Brushes.Blue, DashStyleHelper.Solid, 2);	
			}

			if (PricelineOn)
			{
				Draw.HorizontalLine(this, "PriceLine", false, Close[0], _PriceLineColorDefinedbyUser, DashStyleHelper.Dot, PriceLineThickness);	
			}

			if (!ShowTicksInCorner)
			{
				int tickcounteroffsetx = -1*TickcounteroffsetX;
				if (ShowBarRange)
				{
					if(CurrentBar < tickcounteroffsetx) return;
					Draw.Text(this, "NinjaScriptInfo1", false, tick1 + "  " + RangeString, tickcounteroffsetx, Close[0]+TickcounteroffsetY*TickSize,  0, ChartControl.Properties.ChartText, textFont, TextAlignment.Left, Brushes.Transparent, Brushes.Black, 0);
				}
				else
				{
					if(CurrentBar < tickcounteroffsetx) return;
					Draw.Text(this, "NinjaScriptInfo1", false, tick1, tickcounteroffsetx, Close[0]+TickcounteroffsetY*TickSize,  0, ChartControl.Properties.ChartText, textFont, TextAlignment.Left, Brushes.Transparent, Brushes.Black, 0);
				}	
			}
				
			if (ShowTicksInCorner && ShowATRInCorner)
			{	
			Draw.TextFixed(this, "NinjaScriptInfo", "ticks: " + tick1 + "    ATR: " + atrstring, TextPosition.BottomRight, ChartControl.Properties.ChartText, ChartControl.Properties.LabelFont, Brushes.Transparent, Brushes.Transparent, 0);	
			}	
			
			else
				{
					if (ShowTicksInCorner)
					{	
					Draw.TextFixed(this, "NinjaScriptInfo", "ticks: " + tick1, TextPosition.BottomRight, ChartControl.Properties.ChartText, ChartControl.Properties.LabelFont, Brushes.Transparent, Brushes.Transparent, 0);	
					}	
			
					if (ShowATRInCorner)
					{	
					Draw.TextFixed(this, "NinjaScriptInfo", "ATR: " + atrstring, TextPosition.BottomRight, ChartControl.Properties.ChartText, ChartControl.Properties.LabelFont, Brushes.Transparent, Brushes.Transparent, 0);	
					}	
				}
			
				
			if (FirstExitOn)
							{	
							LongTarget = High[1] + ((FirstExitTicks + 1) * TickSize);	
							ShortTarget = Low[1] - ((FirstExitTicks + 1) * TickSize);	
							Draw.Line(this, "LongTarget", false, 1, LongTarget, 0, LongTarget, Brushes.Blue, DashStyleHelper.Solid, FirstExitThickness);	
							Draw.Line(this, "ShortTarget", false, 1, ShortTarget, 0, ShortTarget, Brushes.Red, DashStyleHelper.Solid, FirstExitThickness);	
							}	
				
			
		}

		#region Properties
		
		[NinjaScriptProperty]
		[Display(ResourceType = typeof (Custom.Resource), Name = "Count Down Ticks", Order = 1, GroupName = "1. Tick Counter")]
		public bool CountDown
		{ get; set; }

		[NinjaScriptProperty]
		[Display(ResourceType = typeof (Custom.Resource), Name = "Show Ticks as per cent", Order = 2, GroupName = "1. Tick Counter")]
		public bool ShowPercent
		{ get; set; }

		[NinjaScriptProperty]
		[Display(Name="Price Line", Description="PricelineOn", Order=3, GroupName="1. Tick Counter")]
		public bool PricelineOn
		{ get; set; }

		[NinjaScriptProperty]
        [XmlIgnore]
        [Display(Name = "Price Line Color", Description = "Price Line Color", Order = 4, GroupName = "1. Tick Counter")]
        public Brush PriceLineColor
        {
            get { return _PriceLineColorDefinedbyUser; }
            set { _PriceLineColorDefinedbyUser = value; }
        }

		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[Display(Name="Price Line Thickness", Order=5, GroupName="1. Tick Counter")]
		public int PriceLineThickness
		{ get; set; }
		
		[NinjaScriptProperty]
		[Display(Name="Spread Lines", Description="SpreadlinesOn", Order=6, GroupName="1. Tick Counter")]
		public bool SpreadlinesOn
		{ get; set; }

		[NinjaScriptProperty]
		[Display(Name="Prior Bar's Range", Description="Show Size of Prior Bar in Ticks", Order=7, GroupName="1. Tick Counter")]
		public bool ShowBarRange
		{ get; set; }
		
		[Display(Name = "Text Font", Description= "Select font, style, size to display on chart", Order=8, GroupName= "1. Tick Counter")]
		public Gui.Tools.SimpleFont TextFont
		{
			get { return textFont; }
			set { textFont = value; }
		}		

		[NinjaScriptProperty]
//		[Range(-12, 12)]
		[Display(Name="Tick Counter X Display Offset", Description= "Move the tick counter left(-) or right(+) bar count from current bar", Order=9, GroupName="1. Tick Counter")]
		public int TickcounteroffsetX
		{ get; set; }
		
		[NinjaScriptProperty]
//		[Range(-12, 12)]
		[Display(Name="Tick Counter Y Display Offset", Description= "Move the tick counter up(+) or down(-) from the current close + user value * ticksize", Order=10, GroupName="1. Tick Counter")]
		public double TickcounteroffsetY
		{ get; set; }
		
		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[Display(Name="Spread line length", Description= "Adjust the length of the spread lines to the right", Order=11, GroupName="1. Tick Counter")]
		public int Spreadlineslen
		{ get; set; }
		
		[NinjaScriptProperty]
		[Display(Name="Show Ticks", Description="Show Extra Count In Lower Right Corner", Order=14, GroupName="2. Display Lower Right")]
		public bool ShowTicksInCorner
		{ get; set; }
		
		[NinjaScriptProperty]
		[Display(Name="Show ATR", Description="Show ATR In Lower Right Corner", Order=15, GroupName="2. Display Lower Right")]
		public bool ShowATRInCorner
		{ get; set; }
		
		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[Display(Name="ATRperiod", Order=16, GroupName="2. Display Lower Right")]
		public int ATRperiod
		{ get; set; }

		[NinjaScriptProperty]
		[Display(Name="Display in Ticks", Description="Shows values as ticks", Order=22, GroupName="3. Common")]
		public bool DisplayInTicks
		{ get; set; }
				
		[NinjaScriptProperty]
		[Display(Name="Show First Exit", Description="Draws Line at Estimated Scalp Target", Order=31, GroupName="4. First Exit")]
		public bool FirstExitOn
		{ get; set; }
		
		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[Display(Name="Target in Ticks", Description="Number of Ticks to First Target", Order=32, GroupName="4. First Exit")]
		public int FirstExitTicks
		{ get; set; }
		
		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[Display(Name="Line Thickness", Description="Thickness of Line", Order=33, GroupName="4. First Exit")]
		public int FirstExitThickness
		{ get; set; }
		
        [Browsable(false)]
        public string PriceLineColorSerializable
        {
            get { return Serialize.BrushToString(PriceLineColor); }
            set { PriceLineColor = Serialize.StringToBrush(value); }
        }
				
		[Browsable(false)]
		[XmlIgnore]
		public Series<double> EMA21
		{
			get { return Values[0]; }
		}
		
		#endregion
	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private BPxMackPart2[] cacheBPxMackPart2;
		public BPxMackPart2 BPxMackPart2(bool countDown, bool showPercent, bool pricelineOn, Brush priceLineColor, int priceLineThickness, bool spreadlinesOn, bool showBarRange, int tickcounteroffsetX, double tickcounteroffsetY, int spreadlineslen, bool showTicksInCorner, bool showATRInCorner, int aTRperiod, bool displayInTicks, bool firstExitOn, int firstExitTicks, int firstExitThickness)
		{
			return BPxMackPart2(Input, countDown, showPercent, pricelineOn, priceLineColor, priceLineThickness, spreadlinesOn, showBarRange, tickcounteroffsetX, tickcounteroffsetY, spreadlineslen, showTicksInCorner, showATRInCorner, aTRperiod, displayInTicks, firstExitOn, firstExitTicks, firstExitThickness);
		}

		public BPxMackPart2 BPxMackPart2(ISeries<double> input, bool countDown, bool showPercent, bool pricelineOn, Brush priceLineColor, int priceLineThickness, bool spreadlinesOn, bool showBarRange, int tickcounteroffsetX, double tickcounteroffsetY, int spreadlineslen, bool showTicksInCorner, bool showATRInCorner, int aTRperiod, bool displayInTicks, bool firstExitOn, int firstExitTicks, int firstExitThickness)
		{
			if (cacheBPxMackPart2 != null)
				for (int idx = 0; idx < cacheBPxMackPart2.Length; idx++)
					if (cacheBPxMackPart2[idx] != null && cacheBPxMackPart2[idx].CountDown == countDown && cacheBPxMackPart2[idx].ShowPercent == showPercent && cacheBPxMackPart2[idx].PricelineOn == pricelineOn && cacheBPxMackPart2[idx].PriceLineColor == priceLineColor && cacheBPxMackPart2[idx].PriceLineThickness == priceLineThickness && cacheBPxMackPart2[idx].SpreadlinesOn == spreadlinesOn && cacheBPxMackPart2[idx].ShowBarRange == showBarRange && cacheBPxMackPart2[idx].TickcounteroffsetX == tickcounteroffsetX && cacheBPxMackPart2[idx].TickcounteroffsetY == tickcounteroffsetY && cacheBPxMackPart2[idx].Spreadlineslen == spreadlineslen && cacheBPxMackPart2[idx].ShowTicksInCorner == showTicksInCorner && cacheBPxMackPart2[idx].ShowATRInCorner == showATRInCorner && cacheBPxMackPart2[idx].ATRperiod == aTRperiod && cacheBPxMackPart2[idx].DisplayInTicks == displayInTicks && cacheBPxMackPart2[idx].FirstExitOn == firstExitOn && cacheBPxMackPart2[idx].FirstExitTicks == firstExitTicks && cacheBPxMackPart2[idx].FirstExitThickness == firstExitThickness && cacheBPxMackPart2[idx].EqualsInput(input))
						return cacheBPxMackPart2[idx];
			return CacheIndicator<BPxMackPart2>(new BPxMackPart2(){ CountDown = countDown, ShowPercent = showPercent, PricelineOn = pricelineOn, PriceLineColor = priceLineColor, PriceLineThickness = priceLineThickness, SpreadlinesOn = spreadlinesOn, ShowBarRange = showBarRange, TickcounteroffsetX = tickcounteroffsetX, TickcounteroffsetY = tickcounteroffsetY, Spreadlineslen = spreadlineslen, ShowTicksInCorner = showTicksInCorner, ShowATRInCorner = showATRInCorner, ATRperiod = aTRperiod, DisplayInTicks = displayInTicks, FirstExitOn = firstExitOn, FirstExitTicks = firstExitTicks, FirstExitThickness = firstExitThickness }, input, ref cacheBPxMackPart2);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.BPxMackPart2 BPxMackPart2(bool countDown, bool showPercent, bool pricelineOn, Brush priceLineColor, int priceLineThickness, bool spreadlinesOn, bool showBarRange, int tickcounteroffsetX, double tickcounteroffsetY, int spreadlineslen, bool showTicksInCorner, bool showATRInCorner, int aTRperiod, bool displayInTicks, bool firstExitOn, int firstExitTicks, int firstExitThickness)
		{
			return indicator.BPxMackPart2(Input, countDown, showPercent, pricelineOn, priceLineColor, priceLineThickness, spreadlinesOn, showBarRange, tickcounteroffsetX, tickcounteroffsetY, spreadlineslen, showTicksInCorner, showATRInCorner, aTRperiod, displayInTicks, firstExitOn, firstExitTicks, firstExitThickness);
		}

		public Indicators.BPxMackPart2 BPxMackPart2(ISeries<double> input , bool countDown, bool showPercent, bool pricelineOn, Brush priceLineColor, int priceLineThickness, bool spreadlinesOn, bool showBarRange, int tickcounteroffsetX, double tickcounteroffsetY, int spreadlineslen, bool showTicksInCorner, bool showATRInCorner, int aTRperiod, bool displayInTicks, bool firstExitOn, int firstExitTicks, int firstExitThickness)
		{
			return indicator.BPxMackPart2(input, countDown, showPercent, pricelineOn, priceLineColor, priceLineThickness, spreadlinesOn, showBarRange, tickcounteroffsetX, tickcounteroffsetY, spreadlineslen, showTicksInCorner, showATRInCorner, aTRperiod, displayInTicks, firstExitOn, firstExitTicks, firstExitThickness);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.BPxMackPart2 BPxMackPart2(bool countDown, bool showPercent, bool pricelineOn, Brush priceLineColor, int priceLineThickness, bool spreadlinesOn, bool showBarRange, int tickcounteroffsetX, double tickcounteroffsetY, int spreadlineslen, bool showTicksInCorner, bool showATRInCorner, int aTRperiod, bool displayInTicks, bool firstExitOn, int firstExitTicks, int firstExitThickness)
		{
			return indicator.BPxMackPart2(Input, countDown, showPercent, pricelineOn, priceLineColor, priceLineThickness, spreadlinesOn, showBarRange, tickcounteroffsetX, tickcounteroffsetY, spreadlineslen, showTicksInCorner, showATRInCorner, aTRperiod, displayInTicks, firstExitOn, firstExitTicks, firstExitThickness);
		}

		public Indicators.BPxMackPart2 BPxMackPart2(ISeries<double> input , bool countDown, bool showPercent, bool pricelineOn, Brush priceLineColor, int priceLineThickness, bool spreadlinesOn, bool showBarRange, int tickcounteroffsetX, double tickcounteroffsetY, int spreadlineslen, bool showTicksInCorner, bool showATRInCorner, int aTRperiod, bool displayInTicks, bool firstExitOn, int firstExitTicks, int firstExitThickness)
		{
			return indicator.BPxMackPart2(input, countDown, showPercent, pricelineOn, priceLineColor, priceLineThickness, spreadlinesOn, showBarRange, tickcounteroffsetX, tickcounteroffsetY, spreadlineslen, showTicksInCorner, showATRInCorner, aTRperiod, displayInTicks, firstExitOn, firstExitTicks, firstExitThickness);
		}
	}
}

#endregion
